package Java1;

public class CPU {
    public void disp(){
        System.out.println("Hello CPU");
    }
    
}
