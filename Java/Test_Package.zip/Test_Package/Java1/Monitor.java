package Java1;
public class Monitor
{
    public void disp()
    {
        System.out.println("Hello Monitor");
    }
}

