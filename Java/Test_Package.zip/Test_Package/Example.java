import Java1.*;

public class Example {
    public static void main(String[] args)
    {
        //Monitor ob = new Monitor();
        CPU ob = new CPU();
        ob.disp();
    }
}
