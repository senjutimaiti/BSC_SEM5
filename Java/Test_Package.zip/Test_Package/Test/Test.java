package Test
public class Test{
	public static void main(String[] args)
	{
		Dog d = new Dog("bark");
		d.display();
	}
}
